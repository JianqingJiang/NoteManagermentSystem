package db;
import java.sql.Connection;
import java.sql.DriverManager;
public class DbClass {
	 public Connection getConn()throws Exception{
		 Connection conn;
		  Class.forName("com.mysql.jdbc.Driver");
		  conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
		   return conn;
	  }
}
